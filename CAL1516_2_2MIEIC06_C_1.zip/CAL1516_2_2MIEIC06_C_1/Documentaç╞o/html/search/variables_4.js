var searchData=
[
  ['maxlat',['maxLat',['../struct_limit_coords.html#a9a0fcf9e011923cb568a1c584a51f654',1,'LimitCoords']]],
  ['maxlong',['maxLong',['../struct_limit_coords.html#aeaddaee7845266a6f234ffd50f748ae4',1,'LimitCoords']]],
  ['minlat',['minLat',['../struct_limit_coords.html#a1a647ec24500cd353ef30d0de159f0be',1,'LimitCoords']]],
  ['minlong',['minLong',['../struct_limit_coords.html#a3ef4041cf2ffec8011de8ff137180895',1,'LimitCoords']]]
];
