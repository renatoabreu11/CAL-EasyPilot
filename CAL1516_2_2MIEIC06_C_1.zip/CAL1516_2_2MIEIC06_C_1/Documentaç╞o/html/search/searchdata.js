var indexSectionsWithContent =
{
  0: "abcdefghiklmnoprstuvwy~",
  1: "cegilmstv",
  2: "s",
  3: "cegmsu",
  4: "abcdefghiklmnoprstuv~",
  5: "abdimnpru",
  6: "gv",
  7: "bcdeglmoprwy"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "related",
  7: "defines"
};

var indexSectionLabels =
{
  0: "Tudo",
  1: "Classes",
  2: "Namespaces",
  3: "Ficheiros",
  4: "Funções",
  5: "Variáveis",
  6: "Amigos",
  7: "Macros"
};

