var searchData=
[
  ['light_5fgray',['LIGHT_GRAY',['../graphviewer_8h.html#a9663e02e20b5b578e6a31adae265cb88',1,'graphviewer.h']]],
  ['limitcoords',['LimitCoords',['../struct_limit_coords.html',1,'']]],
  ['link',['Link',['../class_link.html',1,'Link'],['../class_link.html#a1918a8473cee40bbed17b8e926cb85d9',1,'Link::Link()'],['../class_link.html#adb501ce3d816ea3a7dd603aa97c8bce6',1,'Link::Link(unsigned r, unsigned n1, unsigned n2)']]]
];
