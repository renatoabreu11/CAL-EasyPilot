var searchData=
[
  ['link',['Link',['../class_link.html#a1918a8473cee40bbed17b8e926cb85d9',1,'Link::Link()'],['../class_link.html#adb501ce3d816ea3a7dd603aa97c8bce6',1,'Link::Link(unsigned r, unsigned n1, unsigned n2)']]]
];
