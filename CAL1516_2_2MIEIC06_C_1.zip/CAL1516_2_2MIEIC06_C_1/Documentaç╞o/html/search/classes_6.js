var searchData=
[
  ['stringalgorithms',['StringAlgorithms',['../class_string_algorithms.html',1,'']]]
];
