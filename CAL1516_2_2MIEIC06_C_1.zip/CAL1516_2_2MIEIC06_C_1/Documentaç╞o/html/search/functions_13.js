var searchData=
[
  ['vertex',['Vertex',['../class_vertex.html#a32481367e36d2162714bc411f31b5f8f',1,'Vertex']]]
];
