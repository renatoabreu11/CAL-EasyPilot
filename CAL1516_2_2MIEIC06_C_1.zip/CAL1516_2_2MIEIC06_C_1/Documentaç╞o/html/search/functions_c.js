var searchData=
[
  ['navigation',['navigation',['../classstd_1_1_menu_manager.html#a07bff9624aa3fc9104ec98c79b8c37a1',1,'std::MenuManager']]],
  ['navigationoptions',['navigationOptions',['../classstd_1_1_menu_manager.html#a6b49d6cd4fe3260d9642dbb20381f43c',1,'std::MenuManager']]]
];
