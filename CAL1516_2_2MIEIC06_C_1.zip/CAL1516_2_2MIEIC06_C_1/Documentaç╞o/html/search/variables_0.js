var searchData=
[
  ['applied',['applied',['../class_toll.html#a2744c563ee9430acf43cb8ed92cf44d9',1,'Toll']]]
];
